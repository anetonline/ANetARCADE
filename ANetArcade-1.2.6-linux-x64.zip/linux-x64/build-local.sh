#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$HERE/source"
command -v cmake >/dev/null || { echo "cmake is required"; exit 1; }
command -v gcc >/dev/null || { echo "gcc/build-essential is required"; exit 1; }
command -v git >/dev/null || { echo "git is required to fetch OpenDoors"; exit 1; }
if [[ ! -f "$SRC/OpenDoors/CMakeLists.txt" ]]; then
  git clone --depth 1 https://github.com/RealDeuce/OpenDoors.git "$SRC/OpenDoors"
fi
rm -rf "$SRC/build-local"
cmake -S "$SRC" -B "$SRC/build-local" -DCMAKE_BUILD_TYPE=Release   -DANET_ARCADE_BUNDLED_OPENDOORS=ON -DOPENDOORS_BUILD_SHARED=OFF   -DOPENDOORS_BUILD_STATIC=ON -DBUILD_TESTING=OFF
cmake --build "$SRC/build-local" --parallel "$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 2)"
BIN="$(find "$SRC/build-local" -type f -name anetarcade -perm -111 | head -1)"
[[ -n "$BIN" ]] || { echo "Build completed but anetarcade was not found."; exit 1; }
cp "$BIN" "$HERE/anetarcade"
chmod +x "$HERE/anetarcade"
echo "Native rebuild installed: $HERE/anetarcade"
"$HERE/anetarcade" --arcade-version || true
