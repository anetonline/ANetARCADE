#include "arcade.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#ifdef _WIN32
#define strcasecmp _stricmp
#else
#include <strings.h>
#endif
#ifdef _WIN32
#include <direct.h>
#include <windows.h>
#define MKDIR(p) _mkdir(p)
#define SEP '\\'
#else
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#define MKDIR(p) mkdir((p),0755)
#define SEP '/'
#endif
static int g_screen_width=80,g_screen_height=24,g_wide=0;
static void arcade_sleep_ms(unsigned ms){
#ifdef _WIN32
 Sleep((DWORD)ms);
#else
 usleep((useconds_t)ms*1000U);
#endif
}
static int g_speed_percent=100;
static int g_difficulty=DIFF_MEDIUM;
int arcade_difficulty(void){return g_difficulty;}
const char *arcade_difficulty_name(void){return g_difficulty==DIFF_EASY?"EASY":(g_difficulty==DIFF_HARD?"HARD":"MEDIUM");}
void arcade_cycle_difficulty(void){g_difficulty=(g_difficulty+1)%3;}
int arcade_score_multiplier(void){return g_difficulty+1;}
int arcade_speed_percent(void){return g_speed_percent;}
int arcade_frame_delay(int base_ms){int v=(base_ms*g_speed_percent)/100;return v<1?1:v;}
extern void ODScrnEnableCaret(BOOL bEnable);
void arcade_cursor_hide(void){ODScrnEnableCaret(FALSE);od_disp("\x1b[?25l",6,FALSE);}
void arcade_cursor_show(void){od_disp("\x1b[?25h",6,FALSE);ODScrnEnableCaret(TRUE);}

void arcade_detect_screen(void){
 int w=(int)od_control.user_screenwidth,h=(int)od_control.user_screen_length;
 if(w>0)g_screen_width=w;
 if(h>0)g_screen_height=h;
 g_wide=(g_screen_width>=132 && g_screen_height>=37);
}
int arcade_screen_width(void){return g_screen_width;}
int arcade_screen_height(void){return g_screen_height;}
int arcade_is_wide(void){return g_wide;}
int arcade_safe_width(void){return g_wide?131:79;}
int arcade_safe_height(void){return g_wide?36:24;}

static const char *names[GAME_COUNT]={"Frogger","Galaga","Pong","Turtle Bridge","Manhole"};
static char data_dir[260]="data";
static ArcadeConfig cfg={"A-Net Online","Sysop",0,".",100};
static int cfg_was_loaded=0;
static const char *cfg_file="anetarcade.cfg";
static unsigned hash_id(const char*s){unsigned h=2166136261u;while(*s){h^=(unsigned char)*s++;h*=16777619u;}return h;}
static void trim(char*s){size_t n;if(!s)return;n=strlen(s);while(n&&(s[n-1]=='\r'||s[n-1]=='\n'||isspace((unsigned char)s[n-1])))s[--n]=0;while(*s&&isspace((unsigned char)*s))memmove(s,s+1,strlen(s));}
static void cfg_load(void){FILE*f=fopen(cfg_file,"r");char line[700];cfg_was_loaded=0;if(!f)return;cfg_was_loaded=1;while(fgets(line,sizeof(line),f)){char*eq=strchr(line,'=');if(!eq)continue;*eq++=0;trim(line);trim(eq);if(!strcmp(line,"BBS_NAME"))snprintf(cfg.bbs_name,sizeof(cfg.bbs_name),"%s",eq);else if(!strcmp(line,"SYSOP_NAME"))snprintf(cfg.sysop_name,sizeof(cfg.sysop_name),"%s",eq);else if(!strcmp(line,"EXPORT_HIGH_SCORES"))cfg.export_scores=(!strcasecmp(eq,"true")||!strcmp(eq,"1")||!strcasecmp(eq,"yes"));else if(!strcmp(line,"HIGH_SCORES_PATH"))snprintf(cfg.score_path,sizeof(cfg.score_path),"%s",eq);else if(!strcmp(line,"SPEED_PERCENT")){int n=atoi(eq);if(n>=50&&n<=200){cfg.speed_percent=n;g_speed_percent=n;}}}fclose(f);}
static int cfg_save(void){FILE*f=fopen(cfg_file,"w");if(!f)return 0;fprintf(f,"# A-Net Arcade configuration\nBBS_NAME=%s\nSYSOP_NAME=%s\nEXPORT_HIGH_SCORES=%s\nHIGH_SCORES_PATH=%s\nSPEED_PERCENT=%d\n",cfg.bbs_name,cfg.sysop_name,cfg.export_scores?"true":"false",cfg.score_path,cfg.speed_percent);fclose(f);return 1;}
const ArcadeConfig *arcade_config(void){return &cfg;}
static void console_get(const char*prompt,char*out,size_t n,const char*def){char b[700];printf("%s",prompt);if(def&&*def)printf(" [%s]",def);printf(": ");fflush(stdout);if(!fgets(b,sizeof(b),stdin)){if(def)snprintf(out,n,"%s",def);return;}trim(b);snprintf(out,n,"%s",*b?b:(def?def:""));}
int arcade_run_config(void){char b[700];cfg_load();printf("\n============================================================\n          A-NET ARCADE CONFIGURATION UTILITY\n============================================================\n\n");console_get("BBS NAME",cfg.bbs_name,sizeof(cfg.bbs_name),cfg.bbs_name);console_get("SYSOP NAME",cfg.sysop_name,sizeof(cfg.sysop_name),cfg.sysop_name);for(;;){console_get("DO YOU WANT HIGH SCORES .ANS AND .ASC MADE (true/false)",b,sizeof(b),cfg.export_scores?"true":"false");if(!strcasecmp(b,"true")||!strcasecmp(b,"yes")||!strcmp(b,"1")){cfg.export_scores=1;break;}if(!strcasecmp(b,"false")||!strcasecmp(b,"no")||!strcmp(b,"0")){cfg.export_scores=0;break;}puts("Please enter true or false.");}if(cfg.export_scores)console_get("PATH-TO-HIGH_SCORES",cfg.score_path,sizeof(cfg.score_path),cfg.score_path);{char sb[32],df[16];snprintf(df,sizeof(df),"%d",cfg.speed_percent);console_get("ANIMATION SPEED PERCENT (50-200; 100=normal)",sb,sizeof(sb),df);{int n=atoi(sb);cfg.speed_percent=(n>=50&&n<=200)?n:100;g_speed_percent=cfg.speed_percent;}}if(!cfg_save()){fprintf(stderr,"ERROR: could not write %s\n",cfg_file);return 1;}printf("\n[OK] Saved %s\n",cfg_file);if(cfg.export_scores){MKDIR(cfg.score_path);export_highscores();printf("[OK] Score exports enabled: %s\n",cfg.score_path);}else puts("[OK] Score exports disabled.");return 0;}
void arcade_init_paths(void){MKDIR(data_dir);cfg_load();g_speed_percent=(cfg.speed_percent>=50&&cfg.speed_percent<=200)?cfg.speed_percent:100;if(cfg.export_scores)MKDIR(cfg.score_path);}
static void path_for(char*out,size_t n,const char*kind,const char*id){snprintf(out,n,"%s/%s_%08x.dat",data_dir,kind,hash_id(id));}
int player_load(Player*p){char fn[320],line[256];FILE*f;const char*id=od_get_user_id();memset(p,0,sizeof(*p));if(!id||!*id)id=od_control.user_name;snprintf(p->id,sizeof(p->id),"%s",id?id:"unknown");path_for(fn,sizeof(fn),"player",p->id);f=fopen(fn,"r");if(!f)return 0;while(fgets(line,sizeof(line),f)){char*k=strtok(line,"=\r\n"),*v=strtok(NULL,"\r\n");if(!k||!v)continue;if(!strcmp(k,"handle"))snprintf(p->handle,sizeof(p->handle),"%s",v);else if(!strncmp(k,"best",4)){int i=atoi(k+4);if(i>=0&&i<GAME_COUNT)p->best[i]=atol(v);}else if(!strncmp(k,"plays",5)){int i=atoi(k+5);if(i>=0&&i<GAME_COUNT)p->plays[i]=strtoul(v,NULL,10);}else if(!strcmp(k,"total"))p->total_plays=strtoul(v,NULL,10);}fclose(f);return 1;}
int player_save(const Player*p){char fn[320];FILE*f;int i;path_for(fn,sizeof(fn),"player",p->id);f=fopen(fn,"w");if(!f)return 0;fprintf(f,"handle=%s\ntotal=%lu\n",p->handle,p->total_plays);for(i=0;i<GAME_COUNT;i++)fprintf(f,"best%d=%ld\nplays%d=%lu\n",i,p->best[i],i,p->plays[i]);fclose(f);return 1;}
static int visible_len(const char*s){int n=0;while(*s){if(*s=='|'&&isdigit((unsigned char)s[1])&&isdigit((unsigned char)s[2]))s+=3;else{n++;s++;}}return n;}
void render_pipe(const char*s){static const char*c[16]={"black","blue","green","cyan","red","magenta","brown","light gray","dark gray","bright blue","bright green","bright cyan","bright red","bright magenta","yellow","white"};while(*s){if(*s=='|'&&isdigit((unsigned char)s[1])&&isdigit((unsigned char)s[2])){int x=(s[1]-'0')*10+s[2]-'0';if(x>=0&&x<16)od_printf("`%s`",c[x]);s+=3;}else{char b[2]={*s++,0};od_disp_str(b);}}od_printf("`white`");}
static void read_line(char*out,int max){int n=0;for(;;){char ch=od_get_key(TRUE);if(ch=='\r'||ch=='\n'){od_disp_str("\n\r");break;}if((ch==8||ch==127)&&n){n--;out[n]=0;od_disp_str("\b \b");continue;}if(ch>=32&&ch<127&&n<max-1){out[n++]=ch;out[n]=0;{char b[2]={ch,0};od_disp_str(b);}}}}
static void color_legend(void){
 static const char*c[16]={"black","blue","green","cyan","red","magenta","brown","light gray","dark gray","bright blue","bright green","bright cyan","bright red","bright magenta","yellow","white"};
 int i;
 od_printf("`dark gray`Pipe colors: `white`");
 for(i=1;i<16;i++){od_printf("`%s`|%02d",c[i],i);if(i<15)od_printf("`white` ");}
 od_printf("`white`\n\r`dark gray`Example: `white`|04Sti|01ng|04Ra|01y\n\r`dark gray`Looks like: `white`");
 render_pipe("|04Sti|01ng|04Ra|01y");
 od_printf("\n\r");
}
static void halfblock_marquee(const char *text,const char *color){
 int i,w=arcade_safe_width(),n=(int)strlen(text),col=1+(w-n)/2;
 od_set_cursor(1,1);od_printf("`%s`",color);for(i=0;i<w;i++)od_printf("\xDC");
 od_set_cursor(2,1);od_printf("`%s`\xDB`white`",color);od_set_cursor(2,col);od_printf("`bright white`%s`white`",text);od_set_cursor(2,w);od_printf("`%s`\xDB`white`",color);
 od_set_cursor(3,1);od_printf("`%s`",color);for(i=0;i<w;i++)od_printf("\xDF");od_printf("`white`");
}
void ensure_handle(Player*p){char tmp[HANDLE_MAX+1],banner[72];for(;;){if(p->handle[0])return;od_clr_scr();snprintf(banner,sizeof(banner),"INSERT COIN - CREATE YOUR ARCADE ID   v%s",ARCADE_VERSION);halfblock_marquee(banner,"bright cyan");od_set_cursor(5,1);color_legend();od_printf("\n\rMaximum `bright green`24 visible characters`white`; pipe codes do not count.\n\r\n\rArcade handle: ");memset(tmp,0,sizeof(tmp));read_line(tmp,sizeof(tmp));if(visible_len(tmp)<1||visible_len(tmp)>24){od_printf("`bright red`Handle must be 1-24 visible characters.`white`\n\r");pause_key();continue;}od_printf("\n\r`yellow`YOUR PLAYER CARD`white`\n\r  Stored code : `dark gray`%s`white`\n\r  On screen   : ",tmp);render_pipe(tmp);od_printf("\n\r\n\rIs this correct? `bright green`[Y]es`white` / `bright red`[N]o`white`: ");for(;;){char c=od_get_key(TRUE);if(c=='y'||c=='Y'){snprintf(p->handle,sizeof(p->handle),"%s",tmp);player_save(p);od_disp_str("Yes\n\r");return;}if(c=='n'||c=='N'){od_disp_str("No\n\r");break;}}}}

static int frame_w(void){return arcade_safe_width();}
static void put_repeat(unsigned char ch,int n){int i;for(i=0;i<n;i++)od_printf("%c",ch);}
static void hline(unsigned char left,unsigned char fill,unsigned char right,const char*color){
 int w=frame_w();od_printf("`%s`%c",color,left);put_repeat(fill,w-2);od_printf("%c`white`",right);
}
static void hline_at(int row,unsigned char left,unsigned char fill,unsigned char right,const char*color){
 od_set_cursor(row,1);hline(left,fill,right,color);
}
static void centered_frame_line_at(int row,const char *text,const char *color){
 int w=frame_w(),inner=w-2,n=(int)strlen(text),l=(inner-n)/2,r=inner-n-l;
 if(l<0)l=0;if(r<0)r=0;
 od_set_cursor(row,1);od_printf("`%s`\xB3`bright white`%*s%s%*s`%s`\xB3`white`",color,l,"",text,r,"",color);
}
static void frame_box(int top,int bottom,const char *color){
 int row;hline_at(top,0xDA,0xC4,0xBF,color);
 for(row=top+1;row<bottom;row++){od_set_cursor(row,1);od_printf("`%s`\xB3",color);od_set_cursor(row,frame_w());od_printf("\xB3`white`");}
 hline_at(bottom,0xC0,0xC4,0xD9,color);
}
void header(const char*t,const Player*p){
 od_clr_scr();hline_at(1,0xDA,0xC4,0xBF,"bright cyan");
 centered_frame_line_at(2,"A - N E T   A R C A D E   2 0 2 6","bright cyan");
 hline_at(3,0xC0,0xC4,0xD9,"bright cyan");
 od_set_cursor(5,3);od_printf("`yellow`%-28.28s`white` Player: ",t);render_pipe(p->handle);
 od_printf("  Plays: `bright green`%lu`white`   ",p->total_plays);
}
void lobby(const Player*p){
 int right=frame_w(), c1=4, c2=arcade_is_wide()?31:25, c3=arcade_is_wide()?61:47;
 od_clr_scr();
 hline_at(1,0xDA,0xC4,0xBF,"bright cyan");
 centered_frame_line_at(2,"A - N E T   A R C A D E   2 0 2 6","bright cyan");
 hline_at(3,0xC3,0xC4,0xB4,"bright cyan");
 od_set_cursor(4,arcade_is_wide()?28:11);od_printf("`bright red`\xAF\xAF `bright green`INSERT COIN`bright red` \\   `bright white`SELECT YOUR GAME`bright red`   \xAF\xAF `bright green`PLAYER ONE`bright red` \\");
 hline_at(5,0xC0,0xC4,0xD9,"bright cyan");
 frame_box(7,11,"bright cyan");
 od_set_cursor(8,c1);od_printf("`bright green`[1]`white` FROGGER 2026");
 od_set_cursor(8,c2);od_printf("`bright green`[2]`white` GALAGA 2026");
 od_set_cursor(8,c3);od_printf("`bright green`[3]`white` PONG");
 od_set_cursor(9,c1);od_printf("`bright green`[4]`white` TURTLE BRIDGE");
 od_set_cursor(9,c2);od_printf("`bright green`[5]`white` MANHOLE 2026");
 od_set_cursor(9,c3);od_printf("`yellow`[S]`white` HALL OF FAME");
 od_set_cursor(10,c1);od_printf("`yellow`[H]`white` HELP / CONTROLS");
 od_set_cursor(10,c2);od_printf("`bright cyan`[D]`white` DIFFICULTY: `yellow`%s`white`",arcade_difficulty_name());
 od_set_cursor(10,c3);od_printf("`bright red`[Q]`white` RETURN TO BBS");
 od_set_cursor(13,2);od_printf("`dark gray`BBS:`white` %-23.23s",cfg.bbs_name);
 od_set_cursor(13,arcade_is_wide()?38:31);od_printf("`dark gray`SYSOP:`white` %-23.23s",cfg.sysop_name);
 od_set_cursor(14,2);od_printf("`dark gray`PLAYER:`white` ");render_pipe(p->handle);
 od_set_cursor(14,arcade_is_wide()?38:31);od_printf("`dark gray`TOTAL PLAYS:`bright green` %lu`white`",p->total_plays);
 od_set_cursor(16,3);od_printf("`yellow`\x10 JOYSTICK READY \x11`white`");
}
void pause_key(void){
 int k;
 od_clear_keybuffer();
 od_printf("\n\r`dark gray`Press C to continue...`white`");
 do { k=od_get_key(TRUE); } while(k!='c' && k!='C' && od_carrier());
}
int poll_key(int ms){tODInputEvent e;if(!od_get_input(&e,(tODMilliSec)ms,GETIN_NORMAL))return 0;if(e.EventType==EVENT_EXTENDED_KEY)return 256+(unsigned char)e.chKeyPress;return (unsigned char)e.chKeyPress;}
int menu_key(void){return toupper((unsigned char)od_get_key(TRUE));}
typedef struct{long score;char handle[64];}Score;
static void load_top(Score top[GAME_COUNT][5],int cnt[GAME_COUNT]){char fn[320],line[256];FILE*f;int g,i,j;memset(top,0,sizeof(Score)*GAME_COUNT*5);memset(cnt,0,sizeof(int)*GAME_COUNT);snprintf(fn,sizeof(fn),"%s/scores.dat",data_dir);f=fopen(fn,"r");if(!f)return;while(fgets(line,sizeof(line),f)){char*a=strtok(line,"|"),*b=strtok(NULL,"|"),*c=strtok(NULL,"|"),*d=strtok(NULL,"\r\n");long s;if(!a||!b||!c||!d)continue;g=atoi(b);if(g<0||g>=GAME_COUNT)continue;s=atol(c);for(i=0;i<5;i++)if(i>=cnt[g]||s>top[g][i].score){for(j=4;j>i;j--)top[g][j]=top[g][j-1];top[g][i].score=s;snprintf(top[g][i].handle,sizeof(top[g][i].handle),"%s",d);if(cnt[g]<5)cnt[g]++;break;}}fclose(f);}
static void strip_pipe(char*out,size_t n,const char*in){size_t j=0;while(*in&&j+1<n){if(*in=='|'&&isdigit((unsigned char)in[1])&&isdigit((unsigned char)in[2]))in+=3;else out[j++]=*in++;}out[j]=0;}
static void ascii_safe(char*out,size_t n,const char*in){size_t j=0;while(*in&&j+1<n){unsigned char c=(unsigned char)*in++;out[j++]=(c>=32&&c<127)?(char)c:'?';}out[j]=0;}
static void join_path(char*out,size_t n,const char*dir,const char*file){size_t l=strlen(dir);if(l&&dir[l-1]!='/'&&dir[l-1]!='\\')snprintf(out,n,"%s%c%s",dir,SEP,file);else snprintf(out,n,"%s%s",dir,file);}
void export_highscores(void){Score top[GAME_COUNT][5];int cnt[GAME_COUNT],g,i;char fn[700],plain[80],bbsplain[80];FILE*f;if(!cfg.export_scores)return;load_top(top,cnt);ascii_safe(bbsplain,sizeof(bbsplain),cfg.bbs_name);MKDIR(cfg.score_path);join_path(fn,sizeof(fn),cfg.score_path,"highscores.asc");f=fopen(fn,"wb");if(f){fprintf(f,"+==============================================================================+\r\n|                         A-NET ARCADE HIGH SCORES                             |\r\n| %-76.76s |\r\n+==============================================================================+\r\n",bbsplain);for(g=0;g<GAME_COUNT;g++){fprintf(f,"\r\n%-16s\r\n",names[g]);for(i=0;i<cnt[g];i++){strip_pipe(plain,sizeof(plain),top[g][i].handle);{char safe[80];ascii_safe(safe,sizeof(safe),plain);snprintf(plain,sizeof(plain),"%s",safe);}fprintf(f," %d. %8ld  %s\r\n",i+1,top[g][i].score,plain);}}fclose(f);}join_path(fn,sizeof(fn),cfg.score_path,"highscores.ans");f=fopen(fn,"wb");if(f){fprintf(f,"\x1b[2J\x1b[H\x1b[1;36m\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB\r\n\xBA\x1b[1;37m              A - N E T   A R C A D E   H A L L   O F   F A M E       \x1b[1;36m\xBA\r\n\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC\x1b[0;37m\r\n");for(g=0;g<GAME_COUNT;g++){fprintf(f,"\r\n\x1b[1;33m%-16s\x1b[0;37m\r\n",names[g]);for(i=0;i<cnt[g];i++){strip_pipe(plain,sizeof(plain),top[g][i].handle);{char safe[80];ascii_safe(safe,sizeof(safe),plain);snprintf(plain,sizeof(plain),"%s",safe);}fprintf(f," \x1b[1;36m%d. %8ld\x1b[0;37m  %s\r\n",i+1,top[g][i].score,plain);}}fprintf(f,"\x1b[0m");fclose(f);}}
void record_score(Player*p,int g,long s){char fn[320];FILE*f;p->plays[g]++;p->total_plays++;if(s>p->best[g])p->best[g]=s;player_save(p);snprintf(fn,sizeof(fn),"%s/scores.dat",data_dir);f=fopen(fn,"a");if(f){time_t now=time(NULL);fprintf(f,"%ld|%d|%ld|%s\n",(long)now,g,s,p->handle);fclose(f);}export_highscores();}
void show_scores(const Player*p){
 Score top[GAME_COUNT][5];int cnt[GAME_COUNT],page=0,key,g,i,row;load_top(top,cnt);
 for(;;){
  int first=page*2,last=first+2;if(last>GAME_COUNT)last=GAME_COUNT;
  od_clr_scr();hline_at(1,0xDA,0xC4,0xBF,"bright cyan");
  centered_frame_line_at(2,"A - N E T   A R C A D E   H A L L   O F   F A M E","bright cyan");
  hline_at(3,0xC3,0xC4,0xB4,"bright cyan");
  od_set_cursor(4,3);od_printf("`dark gray`BBS:`white` %-25.25s",cfg.bbs_name);
  od_set_cursor(4,arcade_is_wide()?72:42);od_printf("`dark gray`SYSOP:`white` %-20.20s",cfg.sysop_name);
  hline_at(5,0xC0,0xC4,0xD9,"bright cyan");
  row=7;
  for(g=first;g<last;g++){
   od_set_cursor(row,3);od_printf("`yellow`%s`white`",names[g]);
   od_set_cursor(row,arcade_is_wide()?55:31);od_printf("`dark gray`YOUR BEST:`bright green` %ld`white`",p->best[g]);row++;
   od_set_cursor(row,3);od_printf("`dark gray`-----------------------------------------------`white`");row++;
   if(!cnt[g]){od_set_cursor(row++,6);od_printf("`dark gray`No scores recorded yet.`white`");}
   else for(i=0;i<cnt[g]&&i<5;i++){od_set_cursor(row,6);od_printf("`bright cyan`%d.`white` ",i+1);render_pipe(top[g][i].handle);od_set_cursor(row,arcade_is_wide()?59:35);od_printf("`bright green`%8ld`white`",top[g][i].score);row++;}
   row++;
  }
  od_set_cursor(arcade_is_wide()?34:22,3);od_printf("`dark gray`PAGE %d OF 3`white`",page+1);
  od_set_cursor(arcade_is_wide()?35:23,3);od_printf("`bright green`[N]`white` NEXT   `bright cyan`[B]`white` BACK   `bright red`[Q]`white` QUIT");
  key=toupper((unsigned char)od_get_key(TRUE));
  if(key=='Q'||key==27)break;if(key=='N'&&page<2)page++;else if(key=='B'&&page>0)page--;
 }
}
static void center_plain(int row,const char *color,const char *text){
 int n=(int)strlen(text),col=1+(frame_w()-n)/2;if(col<1)col=1;
 od_set_cursor(row,col);od_printf("`%s`%s`white`",color,text);
}
static void center_handle(int row,const char *prefix,const char *handle){
 int n=(int)strlen(prefix)+visible_len(handle),col=1+(frame_w()-n)/2;if(col<1)col=1;
 od_set_cursor(row,col);od_printf("`white`%s",prefix);render_pipe(handle);
}
void show_goodbye(const Player*p){
 char b[160];od_clr_scr();hline_at(1,0xDA,0xC4,0xBF,"bright cyan");
 centered_frame_line_at(2,"A - N E T   A R C A D E","bright cyan");
 hline_at(3,0xC0,0xC4,0xD9,"bright cyan");
 center_plain(5,"yellow","GAME OVER - THANKS FOR PLAYING!");center_handle(7,"Player: ",p->handle);
 if(cfg_was_loaded){center_plain(10,"bright cyan","NOW RETURNING TO");center_plain(11,"bright green",cfg.bbs_name);snprintf(b,sizeof(b),"Thank your Sysop: %.32s",cfg.sysop_name);center_plain(14,"white",b);center_plain(15,"bright cyan","for installing ANetARCADE!");}
 else{center_plain(10,"bright yellow","ANetARCADE has not been configured.");center_plain(13,"white","Ask your Sysop to run ANetARCADE --arcade-config");center_plain(14,"white","to finish setting up the arcade.");}
 center_plain(18,"dark gray","<< RETURNING TO BBS >>");od_set_cursor(19,1);arcade_sleep_ms(3000);
}
void show_help(void){
 od_clr_scr();
 od_printf("`bright cyan`A-NET ARCADE HELP`white`\n\r\n\r");
 od_printf("Five native OpenDoors games share one profile and Hall of Fame.\n\r\n\r");
 od_printf("`bright cyan`[D] DIFFICULTY`white`: EASY / MEDIUM / HARD\n\r");
 od_printf("Harder modes increase challenge and award larger score multipliers.\n\r");
 od_printf("Difficulty changes lives, speeds, reaction time, and progression.\n\r\n\r");
 od_printf("`bright green`Frogger`white`: Cross traffic, ride logs, and reach HOME.\n\r");
 od_printf("`bright green`Galaga`white`: Destroy formations and dodge enemy fire.\n\r");
 od_printf("`bright green`Pong`white`: First to 7. CPU reaction improves as play advances.\n\r");
 od_printf("`bright green`Turtle Bridge`white`: Deliver packages; heed !3 !2 !1 warnings.\n\r");
 od_printf("`bright green`Manhole`white`: Cover the threatened hole before time expires.\n\r\n\r");
 od_printf("Arrow keys/WASD work where shown. P pauses Frogger. Q quits a game.\n\r");
 pause_key();
}