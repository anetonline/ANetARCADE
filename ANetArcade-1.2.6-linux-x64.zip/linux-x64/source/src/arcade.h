#ifndef ANET_ARCADE_H
#define ANET_ARCADE_H
#include "OpenDoor.h"
#include <stddef.h>
#define ARCADE_VERSION "1.2.6"
#define HANDLE_MAX 63
#define GAME_COUNT 5
#define PATH_MAX_ARCADE 512

typedef struct { char id[96]; char handle[HANDLE_MAX+1]; unsigned long plays[GAME_COUNT]; long best[GAME_COUNT]; unsigned long total_plays; } Player;
typedef struct { char bbs_name[80]; char sysop_name[80]; int export_scores; char score_path[PATH_MAX_ARCADE]; int speed_percent; } ArcadeConfig;
enum { G_FROGGER, G_GALAGA, G_PONG, G_TURTLE, G_MANHOLE };

void arcade_init_paths(void);
void arcade_detect_screen(void);
int arcade_screen_width(void); int arcade_screen_height(void); int arcade_is_wide(void);
int arcade_safe_width(void); int arcade_safe_height(void); int arcade_run_config(void); const ArcadeConfig *arcade_config(void);
enum { DIFF_EASY=0, DIFF_MEDIUM=1, DIFF_HARD=2 };
int arcade_difficulty(void); const char *arcade_difficulty_name(void); void arcade_cycle_difficulty(void); int arcade_score_multiplier(void); int arcade_speed_percent(void); int arcade_frame_delay(int base_ms); void arcade_cursor_hide(void); void arcade_cursor_show(void);
int player_load(Player*); int player_save(const Player*); void ensure_handle(Player*);
void render_pipe(const char*); void header(const char*, const Player*); void lobby(const Player*); void pause_key(void); int poll_key(int ms); int menu_key(void);
void record_score(Player*, int game, long score); void show_scores(const Player*); void show_help(void); void show_goodbye(const Player*); void export_highscores(void);
void game_frogger(Player*); void game_galaga(Player*); void game_pong(Player*); void game_turtle(Player*); void game_manhole(Player*);
#endif
