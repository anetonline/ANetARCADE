#include "arcade.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
static int dirkey(int k){if(k==256+OD_KEY_LEFT||k=='A'||k=='a')return -1;if(k==256+OD_KEY_RIGHT||k=='D'||k=='d')return 1;return 0;}
static int move4(int k,int*x,int*y){if(k==256+OD_KEY_LEFT||k=='a'||k=='A')(*x)--;else if(k==256+OD_KEY_RIGHT||k=='d'||k=='D')(*x)++;else if(k==256+OD_KEY_UP||k=='w'||k=='W')(*y)--;else if(k==256+OD_KEY_DOWN||k=='s'||k=='S')(*y)++;else return 0;return 1;}
static void title(const char *s,const char *color){
 int i,w=arcade_safe_width(),n=(int)strlen(s),col=1+(w-n)/2;
 od_set_cursor(1,1);od_printf("`%s`",color);for(i=0;i<w;i++)od_printf("\xDC");
 od_set_cursor(2,1);od_printf("`%s`\xDB`white`",color);od_set_cursor(2,col);od_printf("`bright white`%s`white`",s);od_set_cursor(2,w);od_printf("`%s`\xDB`white`",color);
 od_set_cursor(3,1);od_printf("`%s`",color);for(i=0;i<w;i++)od_printf("\xDF");od_printf("`white`");
}

static int wrap76(int x){while(x<2)x+=76;while(x>77)x-=76;return x;}
static int on_log_at(int x,int base){int j,d;for(j=0;j<3;j++){int lx=wrap76(base+j*26);for(d=0;d<13;d++)if(wrap76(lx+d)==x)return 1;}return 0;}

static void blank_at(int row,int col,int n){int i;od_set_cursor(row,col);for(i=0;i<n;i++)od_putch(' ');}
static int play_left(void){return arcade_is_wide()?2:1;}
static int play_right(void){return arcade_is_wide()?130:78;}
static int play_center(void){return arcade_is_wide()?66:40;}
static void game_clear_once(void){od_clr_scr();}
static void wide_side_note(const char *game){
 if(!arcade_is_wide())return;
 od_set_cursor(5,91);od_printf("`bright cyan`A-NET ARCADE WIDE MODE`white`");
 od_set_cursor(7,91);od_printf("`dark gray`Detected: %dx%d",arcade_screen_width(),arcade_screen_height());
 od_set_cursor(8,91);od_printf("Safe canvas: 131x36");
 od_set_cursor(10,91);od_printf("`yellow`%s`white`",game);
}
static int diff_lives(void){return arcade_difficulty()==DIFF_EASY?5:(arcade_difficulty()==DIFF_HARD?2:3);}
static int diff_mult(void){return arcade_score_multiplier();}
static int hud_l=-999,hud_level=-999,hud_diff=-999; static long hud_score=-999;
static void hud_reset(void){hud_l=-999;hud_score=-999;hud_level=-999;hud_diff=-999;}
static void hud_dynamic(int lives,long score,int level){
 int r=arcade_is_wide()?35:23,d=arcade_difficulty();
 if(lives==hud_l&&score==hud_score&&level==hud_level&&d==hud_diff)return;
 od_set_cursor(r,1);od_printf("`white`                                                                              ");
 od_set_cursor(r,2);od_printf("`bright red`LIVES:%d  `bright green`SCORE:%-8ld `bright cyan`LEVEL:%-3d `yellow`DIFF:%-6s`white`",lives,score,level,arcade_difficulty_name());
 hud_l=lives;hud_score=score;hud_level=level;hud_diff=d;
}

static int frog_log_cell(int row,int x,int step){
 int col,dir=((row-5)%2==0)?1:-1,shift=step*dir;
 for(col=0;col<4;col++){int lx=3+col*21+shift+(row-5)*5,d;while(lx<2)lx+=76;while(lx>77)lx-=76;for(d=0;d<11;d++){int xx=lx+d;if(xx>77)xx-=76;if(xx==x)return 1;}}
 return 0;
}
static char road_bg(int x){return ((x-1)%3)==0?'-':' ';}
static void frog_restore_cell(int row,int x,int river_step,int traffic_step){
 if(x<1||x>78)return;od_set_cursor(row,x);
 if(row>=5&&row<=9)od_printf(frog_log_cell(row,x,river_step)?"`brown`\xDC":"`cyan`~");
 else if(row>=11&&row<=16)od_printf("`dark gray`%c",road_bg(x));
 else if(row==4||row==10||row==17||(row>=18&&row<=22))od_printf("`green`.");
 else od_printf(" ");
}
static void frog_erase_sprite(int y,int x,int river_step,int traffic_step){
 int d;for(d=-1;d<=1;d++)frog_restore_cell(y,x+d,river_step,traffic_step);
}
static void frog_update_river(int oldstep,int newstep){
 int row,x;if(oldstep==newstep)return;
 for(row=5;row<=9;row++){
  x=2;
  while(x<=77){
   int o=frog_log_cell(row,x,oldstep),n=frog_log_cell(row,x,newstep);
   if(o==n){x++;continue;}
   {int start=x,state=n,len=0;
    while(x<=77){int oo=frog_log_cell(row,x,oldstep),nn=frog_log_cell(row,x,newstep);if(oo==nn||nn!=state)break;len++;x++;}
    od_set_cursor(row,start);od_printf(state?"`brown`":"`cyan`");while(len--)od_printf(state?"\xDC":"~");
   }
  }
 }
 od_printf("`white`");
}
static void frog_draw_river(int step){
 int row,x;for(row=5;row<=9;row++)for(x=2;x<=77;x++)if(frog_log_cell(row,x,step)){od_set_cursor(row,x);od_printf("`brown`\xDC");}
}
static int car_x_for(int lane,int which,int step){
 int dir=(lane%2==0)?1:-1,base=(step*dir+lane*17)%70;if(base<0)base+=70;return 4+(base+which*35)%70;
}
static void frog_erase_cars(int step){
 int lane,which,d;for(lane=0;lane<3;lane++)for(which=0;which<2;which++){int cx=car_x_for(lane,which,step),r=11+lane*2;for(d=0;d<4;d++){od_set_cursor(r,cx+d);od_printf("`dark gray`%c",road_bg(cx+d));od_set_cursor(r+1,cx+d);od_printf("`dark gray`%c",road_bg(cx+d));}}
}
static void frog_draw_cars(int step){
 int lane,which;for(lane=0;lane<3;lane++)for(which=0;which<2;which++){int cx=car_x_for(lane,which,step),r=11+lane*2;od_set_cursor(r,cx);od_printf(which?"`bright red`\xDA\xC4\xC4\xBF":"`yellow`\xDA\xC4\xC4\xBF");od_set_cursor(r+1,cx);od_printf("`light gray`O  O");}
}
void game_frogger(Player*p){
 int x=40,y=22,oldx=40,oldy=22,lives=diff_lives(),level=1,k,tick=0,river_step=0,traffic_step=0;long score=0;int row;
 srand((unsigned)time(NULL));game_clear_once();hud_reset();title("FROGGER 2026","bright green");wide_side_note("FROGGER 2026");
 od_set_cursor(4,1);od_printf("`green`..............................................................................`white`");
 for(row=5;row<=9;row++){od_set_cursor(row,1);od_printf("`cyan`~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`white`");}
 od_set_cursor(10,1);od_printf("`green`..............................................................................`white`");
 for(row=11;row<=16;row++){od_set_cursor(row,1);for(int xx=1;xx<=78;xx++)od_printf("`dark gray`%c",road_bg(xx));}
 od_set_cursor(17,1);od_printf("`green`..............................................................................`white`");for(row=18;row<=22;row++){od_set_cursor(row,1);od_printf("`green`..............................................................................`white`");}
 od_set_cursor(4,35);od_printf("`bright green`[ HOME ]`white`");od_set_cursor(22,28);od_printf("`dark gray`Arrows/WASD  P=Pause  Q=Quit`white`");
 frog_draw_river(0);frog_draw_cars(0);
 while(lives&&od_carrier()){
  int d=arcade_difficulty(),river_div=(d==DIFF_EASY?6:(d==DIFF_HARD?4:5));
  int traffic_div=(d==DIFF_EASY?5:(d==DIFF_HARD?3:4))-(level>3?2:(level-1)/2);
  int dead=0,newriver=tick/(river_div-(level>6?1:0)),newtraffic;if(traffic_div<2)traffic_div=2;newtraffic=tick/traffic_div;
  /* erase exactly one old frog before moving scenery -- no ghost frogs */
  frog_erase_sprite(oldy,oldx,river_step,traffic_step);
  if(newriver!=river_step){frog_update_river(river_step,newriver);river_step=newriver;if(y>=5&&y<=9){int dir=((y-5)%2==0)?1:-1;x+=dir;if(x<2||x>77)dead=1;}}
  if(newtraffic!=traffic_step){frog_erase_cars(traffic_step);traffic_step=newtraffic;frog_draw_cars(traffic_step);}
  if(y>=5&&y<=9&&!frog_log_cell(y,x,river_step))dead=1;
  for(int lane=0;lane<3;lane++)for(int which=0;which<2;which++){int cx=car_x_for(lane,which,traffic_step),r=11+lane*2;if((y==r||y==r+1)&&x>=cx&&x<=cx+3)dead=1;}
  if(dead){lives--;x=40;y=22;}if(lives<=0)break;
  od_set_cursor(y,x-1);od_printf("`bright green`\xDB\xDC\xDB`white`");oldx=x;oldy=y;hud_dynamic(lives,score,level);
  k=poll_key(arcade_frame_delay(105));if(k=='q'||k=='Q')break;
  if(k=='p'||k=='P'){od_set_cursor(22,2);od_printf("`yellow`PAUSED`white`");pause_key();od_set_cursor(22,2);od_printf("`dark gray`                                                       `white`");}
  else if(move4(k,&x,&y)){if(x<2)x=2;if(x>76)x=76;if(y<4)y=4;if(y>22)y=22;if(k==256+OD_KEY_UP||k=='w'||k=='W')score+=10*diff_mult();}
  if(y<=4){score+=500*level*diff_mult();level++;if(level%3==0)lives++;x=40;y=22;}tick++;
 }
 record_score(p,G_FROGGER,score);header("FROGGER - GAME OVER",p);od_printf("\n\rScore: `bright green`%ld`white`   Level: %d\n\r",score,level);pause_key();
}

static void galaga_blank(int row,int col,int n){
 int i;if(row<4||row>22||col<1)return;od_set_cursor(row,col);for(i=0;i<n;i++)od_printf(" ");
}
static void galaga_ship(int row,int col){
 od_set_cursor(row,col);od_printf("`bright cyan` /\\ `white`");
 od_set_cursor(row+1,col);od_printf("`bright cyan`/\xDB\xDB\\`white`");
}
static void galaga_erase_ship(int row,int col){galaga_blank(row,col,4);galaga_blank(row+1,col,4);}
static void galaga_missile(int row,int col){if(row>=4&&row<=19){od_set_cursor(row,col);od_printf("`yellow`\xB3`white`");}}
static void galaga_erase_missile(int row,int col){if(row>=4&&row<=19){od_set_cursor(row,col);od_printf(" ");}}
static void galaga_bomb(int row,int col){if(row>=4&&row<=19){od_set_cursor(row,col);od_printf("`bright red`!`white`");}}
static void galaga_erase_bomb(int row,int col){if(row>=4&&row<=19){od_set_cursor(row,col);od_printf(" ");}}
static void galaga_enemy(int row,int col,int kind){
 od_set_cursor(row,col);
 if(kind==0)od_printf("`bright magenta`<W>`white`");
 else if(kind==1)od_printf("`bright red`<V>`white`");
 else od_printf("`yellow`<M>`white`");
}
void game_galaga(Player*p){
 int px=38,oldpx=38,lives=diff_lives(),level=1,k,tick=0,shot=0,sy=0,sx=0,oldsy=0;long score=0;
 int enemyx[18],enemyy[18],alive[18],i,dir=1,phase=0,oldphase=0;
 int bomb=0,bx=0,by=0,oldby=0,fireclock=0;
 static const int starsx[14]={9,18,47,62,73,12,31,54,70,4,24,41,67,36};
 static const int starsy[14]={4,6,5,7,8,12,14,16,18,20,9,11,15,19};
 srand((unsigned)time(NULL));
 /* compact Galaga-style formation: three organized rows */
 for(i=0;i<18;i++){enemyx[i]=10+(i%6)*10;enemyy[i]=6+(i/6)*2;alive[i]=1;}
 game_clear_once();hud_reset();title("A-NET GALAGA 2026","bright magenta");wide_side_note("GALAGA 2026");
 for(i=0;i<14;i++){od_set_cursor(starsy[i],starsx[i]);od_printf(i%4==0?"`bright white`*":"`dark gray`.");}
 galaga_ship(19,px);
 for(i=0;i<18;i++)if(alive[i])galaga_enemy(enemyy[i],enemyx[i]+phase,i/6);
 od_set_cursor(21,2);od_printf("`bright cyan`MOVE:`white` arrows/A-D   `yellow`FIRE:`white` Space/F   `bright red`Q:`white` Quit");
 while(lives&&od_carrier()){
  if(oldpx!=px){galaga_erase_ship(19,oldpx);galaga_ship(19,px);oldpx=px;}
  if(shot)galaga_erase_missile(oldsy,sx);
  if(bomb)galaga_erase_bomb(oldby,bx);

  oldphase=phase;
  if(tick%(arcade_difficulty()==DIFF_EASY?8:(arcade_difficulty()==DIFF_HARD?5:7))==0){phase+=dir;if(phase>5){phase=5;dir=-1;}if(phase<-5){phase=-5;dir=1;}}
  if(phase!=oldphase){for(i=0;i<18;i++)if(alive[i])galaga_blank(enemyy[i],enemyx[i]+oldphase,3);for(i=0;i<18;i++)if(alive[i])galaga_enemy(enemyy[i],enemyx[i]+phase,i/6);}

  if(shot){
   sy--;
   if(sy<4)shot=0;
   else for(i=0;i<18;i++)if(alive[i]&&sy==enemyy[i]&&sx>=enemyx[i]+phase&&sx<=enemyx[i]+phase+2){
    alive[i]=0;score+=100*diff_mult();shot=0;galaga_blank(enemyy[i],enemyx[i]+phase,3);break;
   }
  }

  /* Enemy fire: one visible shot at a time, increasingly frequent by level. */
  if(bomb){
   by++;
   if(by>=19){
    if(bx>=px&&bx<=px+3){lives--;score=score>=50?score-50:0;}
    bomb=0;
   }
  }else{
   int base=(arcade_difficulty()==DIFF_EASY?34:(arcade_difficulty()==DIFF_HARD?22:28));int interval=base-(level>6?12:level*2);if(interval<8)interval=8;
   if(++fireclock>=interval){
    int candidates[18],n=0,pick;
    fireclock=0;
    /* only lowest surviving alien in each column may fire */
    for(int col=0;col<6;col++)for(int rr=2;rr>=0;rr--){int q=rr*6+col;if(alive[q]){candidates[n++]=q;break;}}
    if(n){pick=candidates[rand()%n];bx=enemyx[pick]+phase+1;by=enemyy[pick]+1;oldby=by;bomb=1;}
   }
  }

  if(shot){galaga_missile(sy,sx);oldsy=sy;}
  if(bomb){galaga_bomb(by,bx);oldby=by;}
  hud_dynamic(lives,score,level);

  k=poll_key(arcade_frame_delay(85));
  if(k=='q'||k=='Q')break;
  if(k=='a'||k=='A'||k==256+OD_KEY_LEFT){px-=2;if(px<2)px=2;}
  else if(k=='d'||k=='D'||k==256+OD_KEY_RIGHT){px+=2;if(px>73)px=73;}
  else if((k==' '||k=='f'||k=='F')&&!shot){shot=1;sx=px+1;sy=18;oldsy=sy;}

  {int remaining=0;for(i=0;i<18;i++)remaining+=alive[i];
   if(!remaining){level++;score+=500*diff_mult();if(level%3==0)lives++;for(i=0;i<18;i++){alive[i]=1;enemyx[i]=10+(i%6)*10;enemyy[i]=6+(i/6)*2;}phase=oldphase=0;bomb=0;fireclock=0;}
  }
  tick++;
 }
 galaga_erase_ship(19,oldpx);if(shot)galaga_erase_missile(oldsy,sx);if(bomb)galaga_erase_bomb(oldby,bx);
 record_score(p,G_GALAGA,score);header("GALAGA - GAME OVER",p);od_printf("\n\rScore: `bright green`%ld`white`   Level: %d\n\r",score,level);pause_key();
}

void game_pong(Player*p){
 int py=12,opy=12,cy=12,ocy=12,bx=40,by=12,obx=40,oby=12,dx=1,dy=1,k,us=0,cpu=0,tick=0,level=1;
 srand((unsigned)time(NULL));game_clear_once();hud_reset();title("A-NET PONG","bright cyan");wide_side_note("PONG");
 for(int yy=4;yy<=20;yy++){od_set_cursor(yy,40);od_printf("`dark gray`\xFA");}
 od_set_cursor(22,2);od_printf("`dark gray`W/S or arrows move 2 rows per tap   Q quits`white`");
 while(us<7&&cpu<7&&od_carrier()){
  if(obx!=bx||oby!=by){od_set_cursor(oby,obx);od_printf(obx==40?"`dark gray`\xFA":" ");}
  if(opy!=py)for(int yy=opy-3;yy<=opy+3;yy++){od_set_cursor(yy,3);od_printf(" ");}
  if(ocy!=cy)for(int yy=ocy-3;yy<=ocy+3;yy++){od_set_cursor(yy,77);od_printf(" ");}
  for(int yy=py-3;yy<=py+3;yy++){od_set_cursor(yy,3);od_printf("`bright green`\xDB");}
  for(int yy=cy-3;yy<=cy+3;yy++){od_set_cursor(yy,77);od_printf("`bright red`\xDB");}
  od_set_cursor(by,bx);od_printf("`yellow`O");od_set_cursor(23,2);od_printf("`bright green`PLAYER:%d`white`  `bright red`CPU:%d`white`  `bright cyan`LEVEL:%d`white`  `yellow`DIFF:%-6s`white`",us,cpu,level,arcade_difficulty_name());
  opy=py;ocy=cy;obx=bx;oby=by;k=poll_key(arcade_frame_delay(55));if(k=='q'||k=='Q')break;if(k==256+OD_KEY_UP||k=='w'||k=='W')py-=2;if(k==256+OD_KEY_DOWN||k=='s'||k=='S')py+=2;if(py<7)py=7;if(py>17)py=17;level=1+(us+cpu)/3;{int react=(arcade_difficulty()==DIFF_EASY?5:(arcade_difficulty()==DIFF_HARD?2:3));if(level>=4&&react>1)react--;if(tick%react==0){if(cy<by)cy++;else if(cy>by)cy--;}}bx+=dx;by+=dy;if(by<=4||by>=20)dy=-dy;if(bx<=4){if(abs(by-py)<=4){dx=1;if(rand()%3==0)dy=-dy;}else{cpu++;bx=40;by=12;dx=1;}}if(bx>=76){if(abs(by-cy)<=4)dx=-1;else{us++;bx=40;by=12;dx=-1;}}tick++;
 }
 {long score=(us*1000-cpu*250)*diff_mult();if(score<0)score=0;record_score(p,G_PONG,score);header("PONG - MATCH OVER",p);od_printf("\n\rFinal: You `bright green`%d`white` - CPU `bright red`%d`white`   Score %ld\n\r",us,cpu,score);}pause_key();
}

void game_turtle(Player*p){
 int pos=0,opos=-1,lives=diff_lives(),level=1,k,tick=0,carrying=1;long score=0;int dive[5]={0},odive[5]={-1,-1,-1,-1,-1};srand((unsigned)time(NULL));
 game_clear_once();hud_reset();title("TURTLE BRIDGE 2026","bright cyan");wide_side_note("TURTLE BRIDGE");
 od_set_cursor(7,1);od_printf("`bright blue`~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");od_set_cursor(8,1);od_printf("`cyan`~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");od_set_cursor(9,1);od_printf("`bright blue`~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");od_set_cursor(14,1);od_printf("`cyan`~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");od_set_cursor(15,1);od_printf("`bright blue`~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
 od_set_cursor(10,3);od_printf("`green`\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB");od_set_cursor(11,3);od_printf("`bright green`\xDB HOME BANK \xDB");od_set_cursor(12,3);od_printf("`green`\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB");od_set_cursor(10,65);od_printf("`brown`\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB");od_set_cursor(11,65);od_printf("`yellow`\xDB  TOURIST  \xDB");od_set_cursor(12,65);od_printf("`brown`\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB");
 od_set_cursor(20,2);od_printf("`yellow`PACKAGE ON BOARD`white` - hop right to the tourist");od_set_cursor(21,2);od_printf("`dark gray`Left/Right or A/D   `bright red`!3 !2 !1`dark gray` = turtle about to dive   Q quits`white`");
 while(lives&&od_carrier()){
  {int spawn=(arcade_difficulty()==DIFF_EASY?40:(arcade_difficulty()==DIFF_HARD?28:34))-(level>8?8:level);if(spawn<16)spawn=16;if(tick%spawn==0&&tick){int pick=rand()%5;if(dive[pick]==0)dive[pick]=9;}}
  for(int i=0;i<5;i++)if(dive[i]!=odive[i]){int c=18+i*10;blank_at(10,c,7);blank_at(11,c,7);blank_at(12,c,7);if(dive[i]>=7){od_set_cursor(10,c+1);od_printf("`bright red`!%d!",dive[i]-6);od_set_cursor(11,c);od_printf("`yellow` .--. ");od_set_cursor(12,c);od_printf("`green`(__\xDB__) ");}else if(dive[i]>0){od_set_cursor(11,c);od_printf("`bright cyan` ~~~ ");od_set_cursor(12,c);od_printf("`cyan`  ~~~  ");}else{od_set_cursor(11,c);od_printf("`bright green` .--. ");od_set_cursor(12,c);od_printf("`green`(__\xDB__) ");}odive[i]=dive[i];}
  if(opos!=pos){if(opos>=0){int ox=opos==0?9:(opos==6?71:20+(opos-1)*10);blank_at(10,ox,2);}int px=pos==0?9:(pos==6?71:20+(pos-1)*10);od_set_cursor(10,px);od_printf(carrying?"`bright white`@`yellow`\xFE":"`bright white`@");opos=pos;}
  hud_dynamic(lives,score,level);k=poll_key(arcade_frame_delay(arcade_difficulty()==DIFF_EASY?145:(arcade_difficulty()==DIFF_HARD?105:125)));if(k=='q'||k=='Q')break;{int d=dirkey(k);if(d){pos+=d;if(pos<0)pos=0;if(pos>6)pos=6;if(pos>=1&&pos<=5&&dive[pos-1]>0&&dive[pos-1]<=6){lives--;pos=carrying?0:6;}if(carrying&&pos==6){score+=500*level*diff_mult();carrying=0;level++;if(level%4==0)lives++;od_set_cursor(20,2);od_printf("`bright cyan`DELIVERED!`white` - return left for another package       ");}else if(!carrying&&pos==0){score+=100*diff_mult();carrying=1;od_set_cursor(20,2);od_printf("`yellow`PACKAGE ON BOARD`white` - hop right to the tourist          ");}}}for(int i=0;i<5;i++)if(dive[i]>0)dive[i]--;tick++;
 }
 record_score(p,G_TURTLE,score);header("TURTLE BRIDGE - GAME OVER",p);od_printf("\n\rScore: `bright green`%ld`white`   Level: %d\n\r",score,level);pause_key();
}

void game_manhole(Player*p){
 int cover=0,ocover=-1,lives=diff_lives(),level=1,k,tick=0;long score=0;int danger=-1,odanger=-2,ttl=0,ottl=-1;srand((unsigned)time(NULL));
 game_clear_once();hud_reset();title("MANHOLE 2026","yellow");wide_side_note("MANHOLE 2026");
 od_set_cursor(5,1);od_printf("`dark gray`\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB");od_set_cursor(6,19);od_printf("`light gray`DOWNTOWN A-NET - PEDESTRIAN SAFETY PATROL`white`");od_set_cursor(7,3);od_printf("`dark gray`\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC\xDC`white`");
 for(int i=0;i<4;i++){int r=9+(i/2)*7,c=13+(i%2)*42;od_set_cursor(r+5,c+4);od_printf("`bright cyan`[%d]",i+1);}
 od_set_cursor(22,2);od_printf("`dark gray`Move cover: arrows/WASD or 1-4`white`");od_set_cursor(22,64);od_printf("`dark gray`Q quits`white`");
 while(lives&&od_carrier()){
  if(ttl<=0&&rand()%(arcade_difficulty()==DIFF_EASY?12:(arcade_difficulty()==DIFF_HARD?7:9))==0){int base=arcade_difficulty()==DIFF_EASY?17:(arcade_difficulty()==DIFF_HARD?11:14);danger=rand()%4;ttl=base-(level>7?7:level);if(ttl<4)ttl=4;}
  if(danger!=odanger||ttl!=ottl){for(int i=0;i<4;i++){int r=9+(i/2)*7,c=13+(i%2)*42;blank_at(r,c,18);blank_at(r+1,c,18);}if(danger>=0){int r=9+(danger/2)*7,c=13+(danger%2)*42;od_set_cursor(r,c);if(ttl<=3)od_printf("`bright red`  o  DANGER! %d",ttl);else if(ttl<=6)od_printf("`yellow`  o  WARNING... ");else od_printf("`yellow`  o  walking... ");od_set_cursor(r+1,c);od_printf("`white` /|\\");}odanger=danger;ottl=ttl;}
  if(cover!=ocover){for(int i=0;i<4;i++){int r=9+(i/2)*7,c=13+(i%2)*42;od_set_cursor(r+3,c);if(i==cover){od_printf("`bright green`\xDA\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xBF");od_set_cursor(r+4,c);od_printf("`bright green`\xC0\xC4" "COVER" "\xC4\xD9");}else{od_printf("`dark gray`\xDA\xC4\xC4 HOLE \xC4\xBF");od_set_cursor(r+4,c);od_printf("`dark gray`\xB3 \\____/ \xB3");}}ocover=cover;}
  hud_dynamic(lives,score,level);k=poll_key(arcade_frame_delay(115));if(k=='q'||k=='Q')break;if(k>='1'&&k<='4')cover=k-'1';else if(k==256+OD_KEY_LEFT||k=='a'||k=='A')cover=(cover+3)%4;else if(k==256+OD_KEY_RIGHT||k=='d'||k=='D')cover=(cover+1)%4;else if(k==256+OD_KEY_UP||k=='w'||k=='W')cover=(cover+2)%4;else if(k==256+OD_KEY_DOWN||k=='s'||k=='S')cover=(cover+2)%4;if(danger>=0){ttl--;if(ttl<=0){if(cover==danger){score+=100*level*diff_mult();if(score>=level*1000*diff_mult()){level++;if(level%4==0)lives++;}}else lives--;danger=-1;ttl=0;}}tick++;
 }
 record_score(p,G_MANHOLE,score);header("MANHOLE - GAME OVER",p);od_printf("\n\rScore: `bright green`%ld`white`   Level: %d\n\r",score,level);pause_key();
}
