#include "arcade.h"
#include <stdio.h>
#include <string.h>
#ifdef ODPLAT_WIN32
#include <windows.h>
#endif
#ifndef ODPLAT_WIN32
static int is_private_option(int argc,char **argv,const char *opt){return argc==2&&!strcmp(argv[1],opt);}
#endif
static int arcade_main_body(
#ifdef ODPLAT_WIN32
 LPSTR cmdline,int nCmdShow
#else
 int argc,char **argv
#endif
){Player p;int k;
 snprintf(od_control.od_prog_name,sizeof(od_control.od_prog_name),"%s","A-Net Arcade");
 snprintf(od_control.od_prog_version,sizeof(od_control.od_prog_version),"%s",ARCADE_VERSION);
 od_control.od_always_clear=TRUE;
#ifdef ODPLAT_WIN32
 od_control.od_cmd_show=nCmdShow;od_parse_cmd_line(cmdline);
#else
 od_parse_cmd_line(argc,argv);
#endif
 od_init();arcade_detect_screen();arcade_init_paths();arcade_cursor_hide();player_load(&p);ensure_handle(&p);
 for(;;){lobby(&p);k=menu_key();if(k=='1')game_frogger(&p);else if(k=='2')game_galaga(&p);else if(k=='3')game_pong(&p);else if(k=='4')game_turtle(&p);else if(k=='5')game_manhole(&p);else if(k=='D')arcade_cycle_difficulty();else if(k=='S')show_scores(&p);else if(k=='H'||k=='?')show_help();else if(k=='Q'||!od_carrier())break;}
 show_goodbye(&p);arcade_cursor_show();od_exit(0,FALSE);return 0;}
#ifdef ODPLAT_WIN32
static int win_private_option(const char *cmd,const char *opt){size_t n;while(*cmd==' '||*cmd=='\t')cmd++;n=strlen(cmd);while(n&&(cmd[n-1]==' '||cmd[n-1]=='\t'))n--;return strlen(opt)==n&&!strncmp(cmd,opt,n);}
static void win_console(void){AllocConsole();freopen("CONIN$","r",stdin);freopen("CONOUT$","w",stdout);freopen("CONOUT$","w",stderr);}
int WINAPI WinMain(HINSTANCE hi,HINSTANCE hp,LPSTR cmd,int show){(void)hi;(void)hp;
 if(win_private_option(cmd,"--arcade-version")){win_console();printf("ANetARCADE %s\nBuild marker: ANETARCADE-1.2.6-C-CONTINUE\nPress Enter to close...",ARCADE_VERSION);fflush(stdout);getchar();return 0;}
 if(win_private_option(cmd,"--arcade-config")){win_console();return arcade_run_config();}
 return arcade_main_body(cmd,show);}
#else
int main(int argc,char **argv){
 if(is_private_option(argc,argv,"--arcade-version")){printf("ANetARCADE %s\nBuild marker: ANETARCADE-1.2.6-C-CONTINUE\n",ARCADE_VERSION);return 0;}
 if(is_private_option(argc,argv,"--arcade-config"))return arcade_run_config();
 return arcade_main_body(argc,argv);}
#endif
